"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.xmlOptions = void 0;
exports.xmlOptions = {
    ignoreAttributes: false,
    attributeNamePrefix: "@",
    format: true,
};
