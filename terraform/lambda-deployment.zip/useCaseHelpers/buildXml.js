"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildXml = void 0;
const xmlOptions_1 = require("../xmlOptions");
const fast_xml_parser_1 = require("fast-xml-parser");
const buildXml = ({ responseType, response }) => {
    const formattedResponse = {
        [`ns2:${responseType}`]: {
            [responseType]: response,
            "@xmlns:ns2": "http://fms.treas.gov/services/tcsonline",
        },
    };
    const respObj = {
        "S:Envelope": {
            "S:Header": {
                "work:WorkContext": {
                    "#text": "rO0ABXd5ACl3ZWJsb2dpYy5hcHAudGNzb25saW5lLWF wcC02LjAuMC1TTkFQU0hPVAAAANYAAAAjd2VibG9naWMud29ya2FyZWEuU3RyaW5nV29ya0NvbnRleHQAH3Y2LjAuMC1TTkFQU 0hPVF8yMDE1XzEwXzE0XzIyMzgAAA==",
                    "@xmlns:work": "http://oracle.com/weblogic/soap/workarea/",
                },
            },
            "S:Body": formattedResponse,
            "@xmlns:S": "http://schemas.xmlsoap.org/soap/envelope/",
        },
    };
    const builder = new fast_xml_parser_1.XMLBuilder(xmlOptions_1.xmlOptions);
    return builder.build(respObj);
};
exports.buildXml = buildXml;
