"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.completeTransaction = void 0;
const luxon_1 = require("luxon");
const uuid_1 = require("uuid");
const completeTransaction = (transaction) => {
    const now = luxon_1.DateTime.now();
    return Object.assign(Object.assign({}, transaction), { paid: true, paygov_tracking_id: (0, uuid_1.v4)(), payment_date: luxon_1.DateTime.now().toFormat("yyyy-MM-dd"), payment_type: "PLASTIC_CARD", transaction_date: now.toJSDate().toISOString(), transaction_status: "Success", transaction_type: "Sale" });
};
exports.completeTransaction = completeTransaction;
