"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvalidRequestError = void 0;
class InvalidRequestError extends Error {
    constructor(message = "Invalid Request") {
        super(message);
        this.statusCode = 400;
    }
}
exports.InvalidRequestError = InvalidRequestError;
