"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFileS3 = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3Client = new client_s3_1.S3Client({ region: "us-east-1" });
// Helper function to convert a readable stream to a string
function streamToString(stream) {
    return __awaiter(this, void 0, void 0, function* () {
        const chunks = [];
        return new Promise((resolve, reject) => {
            stream.on("data", (chunk) => chunks.push(chunk));
            stream.on("error", reject);
            stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
        });
    });
}
const getFileS3 = (_appContext, Key) => __awaiter(void 0, void 0, void 0, function* () {
    const params = {
        Bucket: process.env.BUCKET_NAME,
        Key,
    };
    const command = new client_s3_1.GetObjectCommand(params);
    try {
        const result = yield s3Client.send(command);
        if (!result.Body)
            throw new Error("Transaction not found!");
        const contents = yield streamToString(result.Body);
        return contents;
    }
    catch (err) {
        console.error("Error retrieving file", err);
        throw err;
    }
});
exports.getFileS3 = getFileS3;
