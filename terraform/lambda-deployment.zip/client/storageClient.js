"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storageClient = void 0;
const getFile_1 = require("./s3/getFile");
const saveFile_1 = require("./s3/saveFile");
const getFile_2 = require("./local/getFile");
const saveFile_2 = require("./local/saveFile");
function storageClient() {
    switch (process.env.NODE_ENV) {
        case "local":
            return {
                getFile: getFile_2.getFileLocal,
                saveFile: saveFile_2.saveFileLocal,
            };
        case "production":
            return {
                getFile: getFile_1.getFileS3,
                saveFile: saveFile_1.saveFileS3,
            };
    }
}
exports.storageClient = storageClient;
