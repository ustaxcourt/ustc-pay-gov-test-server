"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createIfDoesNotExist = void 0;
const fs_1 = require("fs");
const createIfDoesNotExist = (pathToCreate) => {
    const exists = (0, fs_1.existsSync)(pathToCreate);
    if (exists) {
        return;
    }
    (0, fs_1.mkdirSync)(pathToCreate);
};
exports.createIfDoesNotExist = createIfDoesNotExist;
