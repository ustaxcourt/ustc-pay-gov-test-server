"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const getResourceLambda_1 = require("./lambdas/getResourceLambda");
const getPayPageLambda_1 = require("./lambdas/getPayPageLambda");
const handleSoapRequestLambda_1 = require("./lambdas/handleSoapRequestLambda");
const appContext_1 = require("./appContext");
const appContext = (0, appContext_1.createAppContext)();
const app = (0, express_1.default)();
exports.app = app;
// pass raw body to handlers
app.use((req, _res, next) => {
    var data = "";
    req.setEncoding("utf8");
    req.on("data", function (chunk) {
        data += chunk;
    });
    req.on("end", function () {
        req.body = data;
        next();
    });
});
app.use((_req, res, next) => {
    res.locals.appContext = appContext;
    next();
});
app.get("/wsdl", getResourceLambda_1.getResourceLocal);
app.get("/wsdl/:file", getResourceLambda_1.getResourceLocal);
app.get("/pay", getPayPageLambda_1.getPayPageLambda);
app.get("/:file", getResourceLambda_1.getResourceLocal);
app.post("/wsdl", handleSoapRequestLambda_1.handleSoapRequestLocal);
