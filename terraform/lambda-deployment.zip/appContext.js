"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAppContext = void 0;
const storageClient_1 = require("./client/storageClient");
const getResource_1 = require("./useCases/getResource");
const handleCompleteOnlineCollection_1 = require("./useCases/handleCompleteOnlineCollection");
const handleStartOnlineCollection_1 = require("./useCases/handleStartOnlineCollection");
const showPayPage_1 = require("./useCases/showPayPage");
const buildXml_1 = require("./useCaseHelpers/buildXml");
const getCompletedTransaction_1 = require("./persistence/getCompletedTransaction");
const getTransactionRequest_1 = require("./persistence/getTransactionRequest");
const saveCompletedTransaction_1 = require("./persistence/saveCompletedTransaction");
const saveTransactionRequest_1 = require("./persistence/saveTransactionRequest");
const handleCompleteOnlineCollectionWithDetails_1 = require("./useCases/handleCompleteOnlineCollectionWithDetails");
const handleGetDetails_1 = require("./useCases/handleGetDetails");
const completeTransaction_1 = require("./useCaseHelpers/completeTransaction");
function createAppContext() {
    return {
        useCases: () => ({
            getResource: getResource_1.getResource,
            handleCompleteOnlineCollection: handleCompleteOnlineCollection_1.handleCompleteOnlineCollection,
            handleCompleteOnlineCollectionWithDetails: handleCompleteOnlineCollectionWithDetails_1.handleCompleteOnlineCollectionWithDetails,
            handleGetDetails: handleGetDetails_1.handleGetDetails,
            handleStartOnlineCollection: handleStartOnlineCollection_1.handleStartOnlineCollection,
            showPayPage: showPayPage_1.showPayPage,
        }),
        useCaseHelpers: () => ({
            buildXml: buildXml_1.buildXml,
            completeTransaction: completeTransaction_1.completeTransaction,
        }),
        persistenceGateway: () => ({
            getCompletedTransaction: getCompletedTransaction_1.getCompletedTransaction,
            getTransactionRequest: getTransactionRequest_1.getTransactionRequest,
            saveCompletedTransaction: saveCompletedTransaction_1.saveCompletedTransaction,
            saveTransactionRequest: saveTransactionRequest_1.saveTransactionRequest,
        }),
        storageClient: storageClient_1.storageClient,
        files: {},
    };
}
exports.createAppContext = createAppContext;
