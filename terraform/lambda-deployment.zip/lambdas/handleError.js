"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleLocalError = exports.handleLambdaError = void 0;
const handleLambdaError = (err) => {
    console.error(`responding with an error`, err);
    if (err.statusCode && err.statusCode < 500) {
        return {
            statusCode: err.statusCode,
            body: err.message,
        };
    }
    throw err;
};
exports.handleLambdaError = handleLambdaError;
const handleLocalError = (err, res) => {
    console.error(`responding with an error:`, err.message);
    const statusCode = err.statusCode || 500;
    res.status(statusCode).send(err.message);
};
exports.handleLocalError = handleLocalError;
