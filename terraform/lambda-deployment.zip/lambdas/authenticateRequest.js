"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticateRequest = void 0;
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const authenticateRequest = (headers) => {
    if (!headers) {
        throw new UnauthorizedError_1.UnauthorizedError("Missing Authentication");
    }
    let authentication = "empty";
    for (const k of Object.keys(headers)) {
        if (k.toLowerCase() === "authentication") {
            authentication = headers[k];
            break;
        }
    }
    if (authentication !== `Bearer ${process.env.ACCESS_TOKEN}`) {
        throw new UnauthorizedError_1.UnauthorizedError("Missing Authentication");
    }
};
exports.authenticateRequest = authenticateRequest;
