"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const handleError_1 = require("./handleError");
const unauthorizedError = new UnauthorizedError_1.UnauthorizedError("you are not authorized to fail");
const internalServerError = new Error("this is a generic error without a status code");
describe("handleLambdaError", () => {
    it("returns an object with the statusCode if the statusCode is less than 400", () => {
        const handledError = (0, handleError_1.handleLambdaError)(unauthorizedError);
        expect(handledError.statusCode).toBe(403);
    });
    it("does not throw an error if the status code is less than 500", () => {
        expect(() => (0, handleError_1.handleLambdaError)(unauthorizedError)).not.toThrow();
    });
    it("throws an error if the statuscode is not present", () => {
        expect(() => (0, handleError_1.handleLambdaError)(internalServerError)).toThrow();
    });
});
