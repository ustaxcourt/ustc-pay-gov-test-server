"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.parseRequest = exports.handleSoapRequestLocal = void 0;
const fast_xml_parser_1 = require("fast-xml-parser");
const appContext_1 = require("../appContext");
const xmlOptions_1 = require("../xmlOptions");
const authenticateRequest_1 = require("./authenticateRequest");
const handleError_1 = require("./handleError");
const InvalidRequestError_1 = require("../errors/InvalidRequestError");
const parser = new fast_xml_parser_1.XMLParser(xmlOptions_1.xmlOptions);
function handleSoapRequest(appContext, soapRequest) {
    return __awaiter(this, void 0, void 0, function* () {
        const jObj = parser.parse(soapRequest);
        const requestData = jObj["soapenv:Envelope"]["soapenv:Body"];
        const actionKey = Object.keys(requestData)[0];
        switch (actionKey) {
            case "tcs:startOnlineCollection":
                return appContext
                    .useCases()
                    .handleStartOnlineCollection(appContext, requestData[actionKey]["startOnlineCollectionRequest"]);
            case "tcs:completeOnlineCollection":
                return appContext
                    .useCases()
                    .handleCompleteOnlineCollection(appContext, requestData[actionKey]["completeOnlineCollectionRequest"]);
            case "tcs:completeOnlineCollectionWithDetails":
                return appContext
                    .useCases()
                    .handleCompleteOnlineCollectionWithDetails(appContext, requestData[actionKey]["completeOnlineCollectionWithDetailsRequest"]);
            case "tcs:getDetails":
                return appContext
                    .useCases()
                    .handleGetDetails(appContext, requestData[actionKey]["getDetailsRequest"]);
            default:
                throw new InvalidRequestError_1.InvalidRequestError("Could not find correct API");
        }
    });
}
function handleSoapRequestLocal(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            (0, authenticateRequest_1.authenticateRequest)(req.headers);
            const result = yield handleSoapRequest(res.locals.appContext, req.body);
            res.send(result);
        }
        catch (err) {
            (0, handleError_1.handleLocalError)(err, res);
        }
    });
}
exports.handleSoapRequestLocal = handleSoapRequestLocal;
const parseRequest = (requestBody) => {
    if (!requestBody) {
        throw new InvalidRequestError_1.InvalidRequestError("Missing body");
    }
};
exports.parseRequest = parseRequest;
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const appContext = (0, appContext_1.createAppContext)();
        (0, authenticateRequest_1.authenticateRequest)(event.headers);
        (0, exports.parseRequest)(event.body);
        const soapRequest = event.body;
        const result = yield handleSoapRequest(appContext, soapRequest);
        return {
            statusCode: 200,
            body: result,
        };
    }
    catch (err) {
        return (0, handleError_1.handleLambdaError)(err);
    }
});
exports.handler = handler;
