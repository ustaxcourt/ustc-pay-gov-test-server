"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const authenticateRequest_1 = require("./authenticateRequest");
describe("authenticateRequest", () => {
    it("throws an error if nothing is passed in", () => {
        expect(() => (0, authenticateRequest_1.authenticateRequest)()).toThrowError(UnauthorizedError_1.UnauthorizedError);
    });
    it("throws an error if with the incorrect authentication header", () => {
        expect(() => (0, authenticateRequest_1.authenticateRequest)({
            authentication: `Bearer ${process.env.ACCESS_TOKEN} random extra stuff`,
        })).toThrowError(UnauthorizedError_1.UnauthorizedError);
    });
    it("should not throw an error with the correct authentication header", () => {
        expect(() => (0, authenticateRequest_1.authenticateRequest)({
            authentication: `Bearer ${process.env.ACCESS_TOKEN}`,
        })).not.toThrow();
    });
    it("should not throw an error with the correct authentication header in Title Case", () => {
        expect(() => (0, authenticateRequest_1.authenticateRequest)({
            Authentication: `Bearer ${process.env.ACCESS_TOKEN}`,
        })).not.toThrow();
    });
    it("should not throw an error with the correct authentication header in Upper Case", () => {
        expect(() => (0, authenticateRequest_1.authenticateRequest)({
            AUTHENTICATION: `Bearer ${process.env.ACCESS_TOKEN}`,
        })).not.toThrow();
    });
});
