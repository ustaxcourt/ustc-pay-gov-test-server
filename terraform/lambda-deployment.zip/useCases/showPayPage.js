"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.showPayPage = void 0;
const showPayPage = (appContext, { token }) => __awaiter(void 0, void 0, void 0, function* () {
    console.log("handling a pay page", token);
    if (!token) {
        throw "Token not found";
    }
    const transactionRequest = yield appContext
        .persistenceGateway()
        .getTransactionRequest(appContext, token);
    const html = yield appContext
        .storageClient()
        .getFile(appContext, "html/pay.html");
    return html
        .replace("%%urlSuccess%%", transactionRequest.url_success)
        .replace("%%urlCancel%%", transactionRequest.url_cancel);
});
exports.showPayPage = showPayPage;
