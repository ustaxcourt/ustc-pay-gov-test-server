"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleGetDetails = void 0;
const handleGetDetails = (appContext, { paygov_tracking_id }) => __awaiter(void 0, void 0, void 0, function* () {
    const completedTransaction = yield appContext
        .persistenceGateway()
        .getCompletedTransaction(appContext, paygov_tracking_id);
    const getDetailsResponse = {
        transactions: [
            {
                transaction: {
                    paygov_tracking_id: completedTransaction.paygov_tracking_id,
                    agency_tracking_id: completedTransaction.agency_tracking_id,
                    transaction_amount: completedTransaction.transaction_amount,
                    transaction_type: completedTransaction.transaction_type,
                    payment_date: completedTransaction.payment_date,
                    transaction_status: completedTransaction.transaction_status,
                    payment_type: completedTransaction.payment_type,
                },
            },
        ],
    };
    return appContext.useCaseHelpers().buildXml({
        response: getDetailsResponse,
        responseType: "getDetailsResponse",
    });
});
exports.handleGetDetails = handleGetDetails;
