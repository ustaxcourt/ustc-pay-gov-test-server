"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.getResourceLocal = void 0;
const appContext_1 = require("../appContext");
const handleError_1 = require("./handleError");
const authenticateRequest_1 = require("./authenticateRequest");
const getResource = (appContext, filename) => __awaiter(void 0, void 0, void 0, function* () {
    return appContext.useCases().getResource(appContext, { filename });
});
const getResourceLocal = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        (0, authenticateRequest_1.authenticateRequest)(req.headers);
        const result = yield getResource(res.locals.appContext, req.params.file);
        res.send(result);
    }
    catch (err) {
        (0, handleError_1.handleLocalError)(err, res);
    }
});
exports.getResourceLocal = getResourceLocal;
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const appContext = (0, appContext_1.createAppContext)();
    try {
        (0, authenticateRequest_1.authenticateRequest)(event.headers);
        const result = yield getResource(appContext, (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.filename);
        return {
            statusCode: 200,
            body: result,
        };
    }
    catch (err) {
        return (0, handleError_1.handleLambdaError)(err);
    }
});
exports.handler = handler;
