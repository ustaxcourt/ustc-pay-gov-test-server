"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.getPayPageLambda = void 0;
const appContext_1 = require("../appContext");
function getPayPage(appContext, token) {
    return __awaiter(this, void 0, void 0, function* () {
        return appContext.useCases().showPayPage(appContext, { token });
    });
}
function getPayPageLambda(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!req.query.token || typeof req.query.token !== "string") {
            return res.send("no token found");
        }
        const result = yield getPayPage(res.locals.appContext, req.query.token);
        res.send(result);
    });
}
exports.getPayPageLambda = getPayPageLambda;
function handler(event) {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        const appContext = (0, appContext_1.createAppContext)();
        if (!((_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.token) ||
            typeof event.queryStringParameters.token !== "string") {
            return {
                statusCode: 400,
                body: "No token found",
            };
        }
        try {
            const result = yield getPayPage(appContext, event.queryStringParameters.token);
            return {
                statusCode: 200,
                body: result,
                headers: {
                    "Content-Type": "text/html; charset=UTF-8",
                },
            };
        }
        catch (err) {
            console.log(err);
            return {
                statusCode: 500,
                body: "error has occurred",
            };
        }
    });
}
exports.handler = handler;
